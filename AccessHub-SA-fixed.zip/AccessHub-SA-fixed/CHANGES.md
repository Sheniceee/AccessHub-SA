# What was fixed

## Why the app failed on the emulator (the main problems)
1. **Crash right after the splash screen** – `AndroidManifest.xml` only declared `MainActivity`.
   Login, Register, Home, Services, Request, MyRequests and Settings were never registered, so the first
   `startActivity()` threw `ActivityNotFoundException`. All 7 are now declared.
2. **Every API call failed with "Could not connect to the API"** – Android 9+ blocks plain `http://` traffic and the app
   talks to `http://10.0.2.2:5000`. Added `res/xml/network_security_config.xml` allowing cleartext **only** for
   `10.0.2.2`, `localhost`, `127.0.0.1`.
3. **API returned HTTP 500 for login/register** – `AuthController` asked for the concrete `TokenService`, but
   `Program.cs` only registers `ITokenService`. Controller now takes `ITokenService`.
4. **API returned HTTP 500 for all `/api/requests` calls** – `AchievementService` was never registered in DI. Registered.
5. **No fixed API port** – added `Properties/launchSettings.json` so `dotnet run` always listens on
   `http://localhost:5000` (what the emulator's `10.0.2.2:5000` reaches). HTTPS redirect is now skipped in Development
   (it would redirect the emulator's HTTP calls and drop the POST body).

## Build / compile errors
- `RequestDao` was missing `insertAll`; `MyRequestsActivity` called a non-existent `getAll()` and
  `RequestSyncWorker` a non-existent `getPending()`. Fixed to use the real DAO methods.
- `InputValidator` did not exist although `InputValidatorTest` tests it. Created `utils/InputValidator.kt`
  (pure Kotlin, so it runs in plain JVM unit tests) and used it in Login/Register.
- Removed the stub `data/local/Syncworker.kt` – it "synced" by only flipping a flag without calling the API.
  The real worker is `sync/RequestSyncWorker.kt`.
- Added missing launcher icons (manifest pointed at a system placeholder) and `proguard-rules.pro`.
- CI: the "Run unit tests" step actually ran `assembleDebug`; it now runs `testDebugUnitTest`.
- `.gitignore` had a corrupted UTF-16 line, and did not ignore `bin/` `obj/` `.vs/`.

## Logic bugs
- **Logout did nothing** – it cleared the `"session"` prefs file while the token lives in `"accesshub_session"`.
  Logout / delete-account now go through `performLogout()` (clears token, local cache and pending sync work).
- **Offline requests appeared twice** after syncing (local copy + server copy). The worker now deletes the local
  placeholder after a successful upload.
- **Offline fallback was too eager** – a 4xx (e.g. expired token) was silently queued offline forever. Now only
  network failures and 5xx are queued; 401/4xx show a message.
- Possible **duplicate uploads** – sync work is now unique (`enqueueUniqueWork`) and the submit button is disabled while sending.
- Room: `fallbackToDestructiveMigration()` so a stale database from an older build can't crash the emulator.
- Saved login is now used (splash goes straight to Home if already logged in).
- Home "Points" / "requests" cards were hard-coded placeholders; they now load from the API.
- Login shows "Server error" for 5xx instead of wrongly saying "Incorrect email or password".
- Registration shows a clear message for "email already exists" (409).
- Login of an account without a password hash (Google-created) no longer throws on the API.
- Retrofit client is created once (not per call); logs headers only, never passwords/tokens.

## UI
- Search boxes now fire on the keyboard's Search key (`imeOptions`/`inputType` were missing).
- Theme changed to Material3 **Light** – text is hard-coded navy and was unreadable in dark mode.
- `fitsSystemWindows` on screens so content isn't hidden under the status bar on Android 15/16 emulators.

## Not changed on purpose
- Gradle wrapper / AGP / Kotlin versions (your project already builds with them).
- `accesshub/AccessHubAndroid/` (a stale nested duplicate of the whole project) is **not** included.
