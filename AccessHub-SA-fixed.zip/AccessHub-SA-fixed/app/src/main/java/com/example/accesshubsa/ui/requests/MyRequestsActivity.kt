package com.example.accesshubsa.ui.requests

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.accesshubsa.data.local.AccessHubDatabase
import com.example.accesshubsa.data.local.ServiceRequest
import com.example.accesshubsa.data.remote.RetrofitClient
import com.example.accesshubsa.databinding.ActivityMyRequestsBinding
import kotlinx.coroutines.launch
import kotlin.coroutines.cancellation.CancellationException

class MyRequestsActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMyRequestsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMyRequestsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val adapter = RequestAdapter(emptyList())
        binding.recyclerRequests.layoutManager = LinearLayoutManager(this)
        binding.recyclerRequests.adapter = adapter

        val dao = AccessHubDatabase.getDatabase(applicationContext).requestDao()

        lifecycleScope.launch {
            // 1) Refresh the local cache from the server (skipped quietly when offline).
            try {
                val response = RetrofitClient.create(this@MyRequestsActivity).getRequests()
                if (response.isSuccessful) {
                    val serverItems = response.body().orEmpty().map {
                        ServiceRequest(
                            id = it.requestId.toLong(),
                            serviceId = it.serviceId,
                            description = it.description,
                            priority = it.priority,
                            status = it.status,
                            synced = true
                        )
                    }
                    dao.insertAll(serverItems)
                } else if (response.code() == 401) {
                    Toast.makeText(
                        this@MyRequestsActivity,
                        "Session expired - showing saved requests only.",
                        Toast.LENGTH_LONG
                    ).show()
                }
            } catch (e: CancellationException) {
                throw e
            } catch (_: Exception) {
                // Offline - fall through and show what is stored locally.
            }

            // 2) Show the cache (server copies + requests still waiting to sync).
            dao.getAllRequests().collect { adapter.update(it) }
        }
    }
}
