package com.example.accesshubsa.ui.home

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.accesshubsa.data.remote.RetrofitClient
import com.example.accesshubsa.databinding.ActivityHomeBinding
import com.example.accesshubsa.ui.login.LoginActivity
import com.example.accesshubsa.ui.requests.MyRequestsActivity
import com.example.accesshubsa.ui.services.ServicesActivity
import com.example.accesshubsa.ui.settings.SettingsActivity
import com.example.accesshubsa.utils.SessionManager
import com.example.accesshubsa.utils.performLogout
import kotlinx.coroutines.launch

class HomeActivity : AppCompatActivity() {
    private lateinit var binding: ActivityHomeBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val firstName = intent.getStringExtra("firstName")
            ?: SessionManager(this).getFirstName()
            ?: "User"
        binding.tvWelcome.text = "Welcome, $firstName"

        binding.btnHealth.setOnClickListener { openServices("Health") }
        binding.btnEducation.setOnClickListener { openServices("Education") }
        binding.btnCommunity.setOnClickListener { openServices("Community") }
        binding.btnGovernment.setOnClickListener { openServices("Government") }

        binding.etSearch.setOnEditorActionListener { _, _, _ ->
            val query = binding.etSearch.text.toString().trim()
            if (query.isNotEmpty()) {
                startActivity(Intent(this, ServicesActivity::class.java).putExtra("searchQuery", query))
            } else {
                Toast.makeText(this, "Enter a service to search", Toast.LENGTH_SHORT).show()
            }
            true
        }

        binding.btnMyRequests.setOnClickListener {
            startActivity(Intent(this, MyRequestsActivity::class.java))
        }

        binding.btnSettings.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        binding.btnLogout.setOnClickListener {
            lifecycleScope.launch {
                // Previously this cleared a different SharedPreferences file than the one the
                // token is stored in, so "Logout" never actually logged anyone out.
                performLogout(this@HomeActivity)
                startActivity(Intent(this@HomeActivity, LoginActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                })
            }
        }
    }

    override fun onResume() {
        super.onResume()
        loadSummary()
    }

    /** Fills the "points" and "requests" cards from the API (silently ignored when offline). */
    private fun loadSummary() {
        lifecycleScope.launch {
            try {
                val api = RetrofitClient.create(this@HomeActivity)
                val profile = api.getProfile()
                if (profile.isSuccessful) {
                    binding.tvPoints.text = "Points: ${profile.body()?.points ?: 0}"
                }
                val requests = api.getRequests()
                if (requests.isSuccessful) {
                    val count = requests.body().orEmpty().size
                    binding.tvRequestStatus.text =
                        if (count == 0) "No active requests" else "You have $count request(s)"
                }
            } catch (_: Exception) {
                // Offline: keep whatever is currently shown.
            }
        }
    }

    private fun openServices(category: String) {
        startActivity(Intent(this, ServicesActivity::class.java).putExtra("category", category))
    }
}
