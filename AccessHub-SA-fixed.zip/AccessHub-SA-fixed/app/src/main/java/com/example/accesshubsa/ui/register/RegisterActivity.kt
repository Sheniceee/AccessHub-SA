package com.example.accesshubsa.ui.register

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.accesshubsa.data.remote.RegisterRequest
import com.example.accesshubsa.data.remote.RetrofitClient
import com.example.accesshubsa.databinding.ActivityRegisterBinding
import com.example.accesshubsa.utils.InputValidator
import kotlinx.coroutines.launch
import java.io.IOException
import kotlin.coroutines.cancellation.CancellationException

class RegisterActivity : AppCompatActivity() {
    private lateinit var binding: ActivityRegisterBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.btnRegister.setOnClickListener { register() }
    }

    private fun register() {
        val first = binding.etFirstName.text.toString().trim()
        val surname = binding.etSurname.text.toString().trim()
        val email = binding.etEmail.text.toString().trim()
        val phone = binding.etPhone.text.toString().trim()
        val password = binding.etPassword.text.toString()
        val confirm = binding.etConfirmPassword.text.toString()

        if (first.isEmpty() || surname.isEmpty() || phone.isEmpty()) {
            Toast.makeText(this, "Complete all required fields.", Toast.LENGTH_SHORT).show()
            return
        }
        if (!InputValidator.isValidEmail(email)) {
            binding.etEmail.error = "Enter a valid email"
            return
        }
        if (!InputValidator.isValidPhone(phone)) {
            binding.etPhone.error = "Enter a valid phone number"
            return
        }
        if (!InputValidator.isValidPassword(password)) {
            binding.etPassword.error = "Minimum 8 characters"
            return
        }
        if (!InputValidator.passwordsMatch(password, confirm)) {
            binding.etConfirmPassword.error = "Passwords do not match"
            return
        }

        binding.btnRegister.isEnabled = false
        lifecycleScope.launch {
            try {
                val response = RetrofitClient.create(this@RegisterActivity).register(
                    RegisterRequest(first, surname, email, phone, password)
                )
                if (response.isSuccessful) {
                    Toast.makeText(
                        this@RegisterActivity,
                        "Registration successful. Please log in.",
                        Toast.LENGTH_LONG
                    ).show()
                    finish()
                    return@launch
                }
                val message = when (response.code()) {
                    409 -> "An account with this email already exists."
                    400 -> "Please check your details and try again."
                    else -> "Registration failed: ${response.code()}"
                }
                Toast.makeText(this@RegisterActivity, message, Toast.LENGTH_LONG).show()
            } catch (e: IOException) {
                Toast.makeText(
                    this@RegisterActivity,
                    "Could not connect to the API. Is it running on port 5000?",
                    Toast.LENGTH_LONG
                ).show()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Toast.makeText(this@RegisterActivity, "Unexpected error: ${e.message}", Toast.LENGTH_LONG).show()
            }
            binding.btnRegister.isEnabled = true
        }
    }
}
