package com.example.accesshubsa.utils

/**
 * Pure-Kotlin input checks (no Android classes), so they can be unit tested on the JVM.
 * android.util.Patterns is NOT available in plain unit tests, which is why a regex is used.
 */
object InputValidator {

    private val EMAIL_REGEX =
        Regex("^[A-Za-z0-9._%+-]+@[A-Za-z0-9-]+(\\.[A-Za-z0-9-]+)+$")

    const val MIN_PASSWORD_LENGTH = 8

    fun isValidEmail(email: String): Boolean = EMAIL_REGEX.matches(email.trim())

    fun isValidPassword(password: String): Boolean = password.length >= MIN_PASSWORD_LENGTH

    /** Lenient phone check: 9-15 digits once spaces, "+" and dashes are ignored. */
    fun isValidPhone(phone: String): Boolean = phone.count { it.isDigit() } in 9..15

    fun passwordsMatch(password: String, confirm: String): Boolean = password == confirm
}
