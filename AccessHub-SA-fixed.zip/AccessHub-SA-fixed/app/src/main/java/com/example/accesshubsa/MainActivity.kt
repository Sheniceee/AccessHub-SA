package com.example.accesshubsa

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AppCompatActivity
import com.example.accesshubsa.ui.home.HomeActivity
import com.example.accesshubsa.ui.login.LoginActivity
import com.example.accesshubsa.utils.SessionManager

class MainActivity : AppCompatActivity() {
    private val handler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        handler.postDelayed({
            // Skip the login screen when a session is already saved.
            val session = SessionManager(this)
            val next = if (session.isLoggedIn()) {
                Intent(this, HomeActivity::class.java)
                    .putExtra("firstName", session.getFirstName())
            } else {
                Intent(this, LoginActivity::class.java)
            }
            startActivity(next)
            finish()
        }, 1200)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
