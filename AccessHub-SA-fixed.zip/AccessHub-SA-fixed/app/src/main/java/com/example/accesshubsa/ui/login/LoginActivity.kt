package com.example.accesshubsa.ui.login

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.accesshubsa.data.remote.LoginRequest
import com.example.accesshubsa.data.remote.RetrofitClient
import com.example.accesshubsa.databinding.ActivityLoginBinding
import com.example.accesshubsa.ui.home.HomeActivity
import com.example.accesshubsa.ui.register.RegisterActivity
import com.example.accesshubsa.utils.InputValidator
import com.example.accesshubsa.utils.SessionManager
import kotlinx.coroutines.launch
import java.io.IOException
import kotlin.coroutines.cancellation.CancellationException

class LoginActivity : AppCompatActivity() {
    private lateinit var binding: ActivityLoginBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnLogin.setOnClickListener { login() }
        binding.tvRegister.setOnClickListener {
            startActivity(Intent(this, RegisterActivity::class.java))
        }

        binding.btnGoogle.setOnClickListener {
            Toast.makeText(
                this,
                "Google SSO must be configured with your Firebase/Google project.",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    private fun login() {
        val email = binding.etEmail.text.toString().trim()
        val password = binding.etPassword.text.toString()

        if (!InputValidator.isValidEmail(email)) {
            binding.etEmail.error = "Enter a valid email"
            return
        }

        if (!InputValidator.isValidPassword(password)) {
            binding.etPassword.error = "Minimum 8 characters"
            return
        }

        binding.btnLogin.isEnabled = false
        lifecycleScope.launch {
            try {
                val response = RetrofitClient.create(this@LoginActivity).login(
                    LoginRequest(email, password)
                )

                if (response.isSuccessful) {
                    val body = response.body()
                    if (body == null) {
                        Toast.makeText(this@LoginActivity, "Unexpected server response", Toast.LENGTH_LONG).show()
                    } else {
                        SessionManager(this@LoginActivity)
                            .saveLogin(body.token, body.userId, body.firstName, body.surname, body.email)

                        startActivity(
                            Intent(this@LoginActivity, HomeActivity::class.java)
                                .putExtra("firstName", body.firstName)
                        )
                        finish()
                        return@launch
                    }
                } else if (response.code() == 401) {
                    Toast.makeText(this@LoginActivity, "Incorrect email or password", Toast.LENGTH_SHORT).show()
                } else {
                    // e.g. 500 from the API - not the user's fault, so don't say "wrong password".
                    Toast.makeText(
                        this@LoginActivity,
                        "Server error (${response.code()}). Please try again.",
                        Toast.LENGTH_LONG
                    ).show()
                }
            } catch (e: IOException) {
                Toast.makeText(
                    this@LoginActivity,
                    "Could not connect to the API. Is it running on port 5000?",
                    Toast.LENGTH_LONG
                ).show()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Toast.makeText(this@LoginActivity, "Unexpected error: ${e.message}", Toast.LENGTH_LONG).show()
            }
            binding.btnLogin.isEnabled = true
        }
    }
}
