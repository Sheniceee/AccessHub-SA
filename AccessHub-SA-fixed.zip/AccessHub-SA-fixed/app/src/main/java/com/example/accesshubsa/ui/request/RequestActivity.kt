package com.example.accesshubsa.ui.request

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.work.Constraints
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import com.example.accesshubsa.data.local.AccessHubDatabase
import com.example.accesshubsa.data.local.ServiceRequest
import com.example.accesshubsa.data.remote.CreateRequest
import com.example.accesshubsa.data.remote.RetrofitClient
import com.example.accesshubsa.databinding.ActivityRequestBinding
import com.example.accesshubsa.sync.RequestSyncWorker
import kotlinx.coroutines.launch
import java.io.IOException
import kotlin.coroutines.cancellation.CancellationException

class RequestActivity : AppCompatActivity() {
    private lateinit var binding: ActivityRequestBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRequestBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val serviceId = intent.getIntExtra("serviceId", 0)
        binding.tvSelectedService.text = intent.getStringExtra("serviceName") ?: "Service"
        binding.tvServiceDescription.text = intent.getStringExtra("description") ?: ""

        binding.spinnerPriority.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            arrayOf("Low", "Medium", "High", "Emergency")
        )

        binding.btnSubmitRequest.setOnClickListener {
            submit(serviceId)
        }
    }

    private fun submit(serviceId: Int) {
        val description = binding.etRequestDescription.text.toString().trim()
        val priority = binding.spinnerPriority.selectedItem.toString()

        if (description.isEmpty()) {
            binding.etRequestDescription.error = "Describe your request"
            return
        }
        if (serviceId == 0) {
            Toast.makeText(this, "No service selected.", Toast.LENGTH_SHORT).show()
            return
        }

        // Stop double-taps from creating duplicate requests.
        binding.btnSubmitRequest.isEnabled = false

        lifecycleScope.launch {
            try {
                val response = RetrofitClient.create(this@RequestActivity).createRequest(
                    CreateRequest(serviceId, description, priority)
                )

                when {
                    response.isSuccessful -> {
                        Toast.makeText(this@RequestActivity, "Request submitted.", Toast.LENGTH_LONG).show()
                        finish()
                    }
                    response.code() == 401 -> {
                        Toast.makeText(
                            this@RequestActivity,
                            "Your session has expired. Please log out and log in again.",
                            Toast.LENGTH_LONG
                        ).show()
                        binding.btnSubmitRequest.isEnabled = true
                    }
                    response.code() in 400..499 -> {
                        // The server understood and refused it; retrying offline would never succeed.
                        Toast.makeText(
                            this@RequestActivity,
                            "The server rejected this request (${response.code()}).",
                            Toast.LENGTH_LONG
                        ).show()
                        binding.btnSubmitRequest.isEnabled = true
                    }
                    else -> saveOffline(serviceId, description, priority) // 5xx: try again later
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: IOException) {
                // No connection / timeout: keep the request locally and sync later.
                saveOffline(serviceId, description, priority)
            } catch (e: Exception) {
                Toast.makeText(this@RequestActivity, "Unexpected error: ${e.message}", Toast.LENGTH_LONG).show()
                binding.btnSubmitRequest.isEnabled = true
            }
        }
    }

    private suspend fun saveOffline(serviceId: Int, description: String, priority: String) {
        AccessHubDatabase.getDatabase(applicationContext).requestDao().insert(
            ServiceRequest(
                // Negative placeholder id so it can never collide with a server id.
                id = -System.currentTimeMillis(),
                serviceId = serviceId,
                description = description,
                priority = priority
            )
        )
        val constraints = Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()
        // Unique + APPEND_OR_REPLACE: never run two sync workers at once (would double-post).
        WorkManager.getInstance(applicationContext).enqueueUniqueWork(
            RequestSyncWorker.UNIQUE_NAME,
            ExistingWorkPolicy.APPEND_OR_REPLACE,
            OneTimeWorkRequestBuilder<RequestSyncWorker>().setConstraints(constraints).build()
        )
        Toast.makeText(
            this,
            "Offline: request saved. It will sync automatically when internet returns.",
            Toast.LENGTH_LONG
        ).show()
        finish()
    }
}
