package com.example.accesshubsa.utils

import android.content.Context
import androidx.work.WorkManager
import com.example.accesshubsa.data.local.AccessHubDatabase
import com.example.accesshubsa.sync.RequestSyncWorker
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Ends the session: forgets the token, empties the local request cache (so the next person
 * to log in on this device never sees someone else's requests) and cancels pending sync work.
 */
suspend fun performLogout(context: Context) {
    val app = context.applicationContext
    SessionManager(app).clear()
    WorkManager.getInstance(app).cancelUniqueWork(RequestSyncWorker.UNIQUE_NAME)
    withContext(Dispatchers.IO) {
        AccessHubDatabase.getDatabase(app).clearAllTables()
    }
}
