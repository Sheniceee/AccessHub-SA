package com.example.accesshubsa.data.remote

import android.content.Context
import android.content.pm.ApplicationInfo
import com.example.accesshubsa.utils.SessionManager
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

object RetrofitClient {

    // 10.0.2.2 is the Android emulator's alias for the host PC's "localhost".
    // The API must be running on port 5000 (see AccessHub.Api/Properties/launchSettings.json).
    // On a physical phone, use your PC's LAN IP here AND add it to
    // res/xml/network_security_config.xml (plain HTTP is blocked otherwise).
    private const val BASE_URL = "http://10.0.2.2:5000/"

    @Volatile
    private var api: ApiService? = null

    fun create(context: Context): ApiService {
        val appContext = context.applicationContext
        return api ?: synchronized(this) {
            api ?: build(appContext).also { api = it }
        }
    }

    private fun build(context: Context): ApiService {
        val session = SessionManager(context)

        val client = OkHttpClient.Builder()
            .connectTimeout(10, TimeUnit.SECONDS)
            .readTimeout(20, TimeUnit.SECONDS)
            .writeTimeout(20, TimeUnit.SECONDS)
            .addInterceptor { chain ->
                // The token is read on every call, so login/logout take effect immediately.
                val builder = chain.request().newBuilder()
                session.getToken()?.let { builder.addHeader("Authorization", "Bearer $it") }
                chain.proceed(builder.build())
            }
            .apply {
                val debuggable =
                    context.applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE != 0
                if (debuggable) {
                    // BASIC (not BODY) so passwords and tokens never end up in Logcat.
                    addInterceptor(HttpLoggingInterceptor().apply {
                        level = HttpLoggingInterceptor.Level.BASIC
                    })
                }
            }
            .build()

        return Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(client)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(ApiService::class.java)
    }
}
